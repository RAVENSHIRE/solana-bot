import type { Logger } from '../utils/logger';
import type { TokenBucket } from '../utils/rate-limiter';
import { HttpError } from '../utils/errors';
import { withRetry } from '../utils/retry';

/** Shared JSON transport. Error messages deliberately omit URLs, headers and response bodies. */
export class HttpClient {
  constructor(private readonly o: { name: string; baseUrl: string; limiter: TokenBucket; logger: Logger; timeoutMs: number; retries: number; headers?: Record<string, string> }) {}
  get<T>(route: string, query: Record<string, string | number | boolean> = {}): Promise<T> {
    return this.request<T>('GET', route, query);
  }
  post<T>(route: string, body: unknown): Promise<T> {
    return this.request<T>('POST', route, {}, body);
  }
  private async request<T>(method: string, route: string, query: Record<string, string | number | boolean>, body?: unknown): Promise<T> {
    const url = new URL(this.o.baseUrl.replace(/\/$/, '') + route);
    for (const [key, value] of Object.entries(query)) url.searchParams.set(key, String(value));
    return withRetry(async () => {
      await this.o.limiter.acquire();
      const res = await fetch(url, { method, headers: { Accept: 'application/json', 'Content-Type': 'application/json', ...this.o.headers }, body: body === undefined ? undefined : JSON.stringify(body), signal: AbortSignal.timeout(this.o.timeoutMs) });
      if (!res.ok) {
        if (res.status === 429) {
          const seconds = Number(res.headers.get('retry-after'));
          this.o.limiter.pause(Number.isFinite(seconds) && seconds > 0 ? Math.min(seconds * 1000, 60_000) : 10_000);
        }
        throw new HttpError(res.status, this.o.name, '');
      }
      return await res.json() as T;
    }, { retries: this.o.retries, baseDelayMs: 500, maxDelayMs: 5000 });
  }
}
