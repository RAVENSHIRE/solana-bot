@echo off
setlocal
set "TARGET=%~1"
if not defined TARGET set "TARGET=%~dp0.."
node "%~dp0install-playbook.cjs" "%TARGET%"
pause
