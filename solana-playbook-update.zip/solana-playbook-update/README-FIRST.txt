1. Entpacke den Ordner solana-playbook-update IN deinen vorhandenen solana-bot-Ordner.
2. Starte solana-playbook-update\install-playbook.cmd. Der Installer prueft alle Aenderungen vorab und sichert geaenderte Dateien.
   Alternativ: node install-playbook.cjs "C:\Pfad\zu\solana-bot"
3. Starte im Projektordner start-playbook.cmd und in einem zweiten Fenster dashboard\start-playbook-dashboard.cmd.
4. Dashboard: http://127.0.0.1:3001
Bei einem Konflikt wird vor dem Schreiben abgebrochen. .env und vorhandene Handelsdaten werden nicht angefasst.
Details, Grenzen und Datenanforderungen: PLAYBOOK.md. Keine Live-Transaktionen.
