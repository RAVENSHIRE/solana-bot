/* Guarded, idempotent update. Preflight all changes before writing anything. */
const fs = require('node:fs');
const path = require('node:path');
const manifest = JSON.parse(fs.readFileSync(path.join(__dirname, 'manifest.json'), 'utf8'));
const target = path.resolve(process.argv[2] || '');
if (!process.argv[2]) throw new Error('Usage: node install-playbook.cjs PATH-TO-SOLANA-BOT');
const pkgPath = path.join(target, 'package.json');
const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
if (pkg.name !== 'solana-autonomous-bot') throw new Error('Target is not solana-autonomous-bot');
const changes = new Map();
const normalize = s => s.replace(/\r\n/g, '\n');
for (const [filename, operations] of Object.entries(manifest.patches)) {
  let value = normalize(fs.readFileSync(path.join(target, filename), 'utf8'));
  for (const [before, after] of operations) {
    if (value.includes(after)) continue;
    if (value.split(before).length !== 2) throw new Error(`Patch conflict in ${filename}; no files changed`);
    value = value.replace(before, after);
  }
  changes.set(filename, value);
}
for (const filename of manifest.files) {
  const source = fs.readFileSync(path.join(__dirname, 'files', filename), 'utf8');
  const existing = path.join(target, filename);
  // Windows project already has its transport; preserve it and let TypeScript check compatibility.
  if (filename === 'src/data/http-client.ts' && fs.existsSync(existing)) continue;
  if (fs.existsSync(existing) && normalize(fs.readFileSync(existing, 'utf8')) !== normalize(source))
    throw new Error(`Existing ${filename} differs; no files changed`);
  changes.set(filename, source);
}
pkg.scripts ??= {};
for (const [key, value] of Object.entries(manifest.scripts)) {
  if (pkg.scripts[key] && pkg.scripts[key] !== value) throw new Error(`Script conflict: ${key}; no files changed`);
  pkg.scripts[key] = value;
}
changes.set('package.json', JSON.stringify(pkg, null, 2) + '\n');
const ignorePath = path.join(target, '.gitignore');
let ignore = fs.existsSync(ignorePath) ? normalize(fs.readFileSync(ignorePath, 'utf8')) : '';
ignore = ignore.replace(/^data\/$/m, '/data/');
for (const rule of ['data-playbook/', 'dist-playbook/', 'playbook-backup-*/', 'solana-playbook-update/'])
  if (!ignore.split('\n').includes(rule)) ignore += '\n' + rule + '\n';
changes.set('.gitignore', ignore);
const writes = [...changes].filter(([name, value]) => !fs.existsSync(path.join(target, name)) || normalize(fs.readFileSync(path.join(target, name), 'utf8')) !== normalize(value));
if (!writes.length) { console.log('Playbook already installed.'); process.exit(0); }
const backup = path.join(target, 'playbook-backup-' + new Date().toISOString().replace(/[:.]/g, '-'));
const written = [];
try {
  for (const [filename, value] of writes) {
    const file = path.join(target, filename);
    const old = fs.existsSync(file) ? fs.readFileSync(file) : null;
    if (old) { const saved = path.join(backup, filename); fs.mkdirSync(path.dirname(saved), { recursive: true }); fs.writeFileSync(saved, old); }
    fs.mkdirSync(path.dirname(file), { recursive: true });
    // Track before writing, so even a partial write is restored on failure.
    written.push([file, old]); fs.writeFileSync(file, value);
  }
} catch (error) {
  for (const [file, old] of written.reverse()) { if (old) fs.writeFileSync(file, old); else fs.rmSync(file, { force: true }); }
  throw error;
}
console.log(`Installed ${writes.length} files. Backup: ${backup}`);
console.log('Next: start-playbook.cmd, then dashboard\\start-playbook-dashboard.cmd');
